#ifndef FUNCTION_ABS_MACRO_H
#define FUNCTION_ABS_MACRO_H
#define ABS(x) (x > 0 ? (x) : (x) * -1)
#endif
